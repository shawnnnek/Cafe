THE MIDNIGHT - CAMPUS CAFE
Theme: Late-night campus cafe near Adamson University on San Marcelino Street, Ermita, Manila. Deep aubergine and brass palette with a raven identity.
Hours shown: Daily, 7 AM-3 AM.

Group members and roles:
- Member 1: Design lead and homepage
- Member 2: Menu and story pages
- Member 3: Contact page and content
- Member 4: CSS, accessibility review, and demo

Who coded what:
Replace the member labels above with your group members' names and update roles and page ownership to reflect the work your group actually completes.

Pages: index.html, menu.html, story.html, contact.html
Stylesheet: css/style.css
Artwork: original SVG illustrations in images/
Media: media/latte-making-animation.mp4 (poster: images/latte-making-poster.jpg), original 18-second animation of a barista making a latte

Demo plan (5-7 minutes):
1. Introduce The Midnight and the raven identity.
2. Walk through the four pages and responsive layout.
3. Show the illustrated menu and play the latte-making video.
4. Demonstrate the contact form and required fields.
5. Each member explains their contribution for at least 30 seconds.

Note: The contact form uses a mailto action; replace the example address if your group chooses a real inbox. Remote cafe photography on story.html needs internet access.






